Since ARM V7 architecture is shared among all Linux small boards (except for Raspberry pi 1), binary demos are not supplied.
Simply run make to build them.