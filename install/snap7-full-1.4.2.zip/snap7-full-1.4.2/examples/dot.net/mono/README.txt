use:
  

mono <program><params>


examples:


  mono Client.exe 192.168.0.71


  sudo mono Server.exe (Server needs root rights to listen on port 102)