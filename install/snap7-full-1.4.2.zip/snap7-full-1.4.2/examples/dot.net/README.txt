************************************************************************
The Demo programs and snap7 classes are fully compatible with Mono 2.10.
************************************************************************

/mono       contains mono.sh, to build a group of console demos under unix

/WinConsole contains a VS2013 solution to build a group of console demos
/WinForm    contains a VS2013 solution to build a group of C# and VB.NET WinForm demos


You can use the free Visual Studio Community Edition 2013 (the evolution of the Express edition).